package org.dreamadream.service;

import org.dreamadream.beans.UserDetailsBean;

public interface ProfileService {

	public UserDetailsBean getProfile(UserDetailsBean userDetailsBean);
	
}
